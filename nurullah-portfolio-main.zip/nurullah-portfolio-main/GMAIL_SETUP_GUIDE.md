# Gmail Configuration Guide for Email Functionality

This guide will help you set up Gmail to send emails through your digital marketing portfolio website.

## Step 1: Enable 2-Step Verification (Required)

1. Go to your Google Account: https://myaccount.google.com
2. Click on "Security" in the left sidebar
3. Scroll down to "How you sign in to Google"
4. Click on "2-Step Verification"
5. Follow the prompts to enable 2-Step Verification
   - You'll need to verify your phone number
   - Choose your preferred verification method (text/call)

## Step 2: Generate an App Password

1. After 2-Step Verification is enabled, go to: https://myaccount.google.com/apppasswords
2. You should see a dropdown menu "Select the app and device you're using"
3. Choose "Mail" from the first dropdown
4. Choose "Other (custom name)" from the second dropdown, type "Nurullah Portfolio"
5. Click "Generate"
6. Google will show you a 16-character password
7. **COPY THIS PASSWORD** - You'll need it in the next step

## Step 3: Add Environment Variables to Your Project

1. In your v0 project, click the **Vars** button in the left sidebar (or look for Settings)
2. Add two new environment variables:

   **Variable 1:**
   - Name: `GMAIL_EMAIL`
   - Value: `your-email@gmail.com` (your Gmail address)

   **Variable 2:**
   - Name: `GMAIL_APP_PASSWORD`
   - Value: `paste-the-16-character-password-here` (from Step 2)

   Example:
   \`\`\`
   GMAIL_EMAIL = nurullah@gmail.com
   GMAIL_APP_PASSWORD = abcd efgh ijkl mnop
   \`\`\`

3. Click "Save" or "Add Variable"

## Step 4: Update Contact Information (Optional)

Update the contact information in the contact form to match your details:
- In `components/contact.tsx`, update:
  - Email: `hello@digitalpro.com` → your actual email
  - Phone: `+1 (555) 123-4567` → your phone number
  - Address: Update the office location

## Step 5: Test Your Setup

1. Go to your portfolio website in the preview
2. Scroll to the "Get In Touch" section
3. Fill out the form with test information
4. Click "Send Message"
5. You should see a success message
6. Check your Gmail inbox - you should receive:
   - An admin notification with the form submission
   - A confirmation email to the customer's email address

## Troubleshooting

### "Failed to send message" error
- Verify that both environment variables are correctly set in Vars
- Check that 2-Step Verification is enabled on your Google Account
- Confirm the app password is exactly 16 characters (spaces included)
- Try generating a new app password

### Not receiving emails
- Check your spam/promotions folder
- Make sure the email addresses are correct
- Verify 2-Step Verification is still enabled

### Password incorrect error
- If you changed your Gmail password, your app password becomes invalid
- Generate a new app password and update the `GMAIL_APP_PASSWORD` variable

## Security Notes

- Never share your app password publicly or commit it to GitHub
- App passwords are used only for this application
- You can revoke the app password anytime from https://myaccount.google.com/apppasswords
- The password is safely stored in Vercel's environment variables

## Sending Emails from "Order Now" Buttons

When users click "Order Now" on the pricing page, they will automatically scroll to the contact form. They can then fill out the form to request services for that specific platform/package.
