import nodemailer from "nodemailer"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { name, email, company, message } = await request.json()

    if (!process.env.GMAIL_EMAIL || !process.env.GMAIL_APP_PASSWORD) {
      console.log("[v0] Missing environment variables:", {
        hasEmail: !!process.env.GMAIL_EMAIL,
        hasPassword: !!process.env.GMAIL_APP_PASSWORD,
      })
      return NextResponse.json(
        {
          error:
            "Email service not configured. Please add GMAIL_EMAIL and GMAIL_APP_PASSWORD to environment variables.",
        },
        { status: 500 },
      )
    }

    // Validate inputs
    if (!name || !email || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: process.env.GMAIL_EMAIL,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    })

    try {
      // Send email to you (admin)
      await transporter.sendMail({
        from: process.env.GMAIL_EMAIL,
        to: process.env.GMAIL_EMAIL,
        subject: `New Contact Form Submission from ${name}`,
        html: `
          <h2>New Contact Form Submission</h2>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Company:</strong> ${company || "Not provided"}</p>
          <p><strong>Message:</strong></p>
          <p>${message.replace(/\n/g, "<br>")}</p>
        `,
      })

      // Send confirmation email to customer
      await transporter.sendMail({
        from: process.env.GMAIL_EMAIL,
        to: email,
        subject: "Thank you for contacting us!",
        html: `
          <h2>Thank you, ${name}!</h2>
          <p>We received your message and will get back to you within 24 hours.</p>
          <p>Best regards,<br>Nurullah - Digital Marketer</p>
        `,
      })

      return NextResponse.json({ success: true, message: "Email sent successfully" }, { status: 200 })
    } catch (emailError) {
      console.error("[v0] Email sending error:", emailError)
      throw emailError
    }
  } catch (error) {
    console.error("[v0] Email error:", error)
    const errorMessage = error instanceof Error ? error.message : "Failed to send email"
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
