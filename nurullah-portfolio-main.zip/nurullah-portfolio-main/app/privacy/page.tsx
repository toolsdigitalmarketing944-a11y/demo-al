"use client"

import { useEffect, useState } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ChevronRight } from "lucide-react"

export default function PrivacyPage() {
  const [scrollProgress, setScrollProgress] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight
      const scrolled = window.scrollY
      setScrollProgress((scrolled / windowHeight) * 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const sections = [
    { id: 1, title: "Our Commitment to Your Privacy" },
    { id: 2, title: "Information We Collect" },
    { id: 3, title: "Client Data and Campaign Confidentiality" },
    { id: 4, title: "How We Use Your Information" },
    { id: 5, title: "Data Security" },
    { id: 6, title: "Cookies" },
    { id: 7, title: "Third-Party Links" },
    { id: 8, title: "Your Consent" },
    { id: 9, title: "Changes to This Policy" },
    { id: 10, title: "Contact Us" },
  ]

  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-primary via-accent to-primary"
        style={{ width: `${scrollProgress}%` }}
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        {/* Header */}
        <div className="mb-12 md:mb-16 animate-fade-in">
          <div className="flex items-center gap-2 mb-4 text-accent">
            <ChevronRight size={18} />
            <span className="text-sm md:text-base font-medium">Legal Documents</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            Privacy Policy
          </h1>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl">
            We take your privacy seriously. This policy explains how we collect, use, and protect your information.
          </p>
        </div>

        {/* Table of Contents */}
        <div
          className="mb-12 md:mb-16 p-6 rounded-2xl bg-secondary/30 border border-border/50 backdrop-blur-sm hover:border-primary/50 transition-all duration-300 animate-fade-in"
          style={{ animationDelay: "0.1s" }}
        >
          <h2 className="text-xl md:text-2xl font-semibold mb-6">Table of Contents</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {sections.map((section, index) => (
              <a
                key={section.id}
                href={`#section-${section.id}`}
                className="group flex items-center gap-2 p-3 rounded-lg hover:bg-primary/10 transition-all duration-200"
                style={{ animationDelay: `${0.15 + index * 0.05}s` }}
              >
                <span className="text-primary font-semibold min-w-fit">{section.id}.</span>
                <span className="text-muted-foreground group-hover:text-foreground transition-colors">
                  {section.title}
                </span>
              </a>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="space-y-10 md:space-y-14">
          <section id="section-1" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">1. Our Commitment to Your Privacy</h2>
            <p className="text-muted-foreground leading-relaxed">
              Your privacy is critically important to us. This Privacy Policy outlines how we collect, use, protect, and
              handle your personal and business information when you visit our website or engage our digital marketing
              and SEO services.
            </p>
          </section>

          <section id="section-2" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.25s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">2. Information We Collect</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We may collect the following types of information:
            </p>
            <ul className="list-none space-y-3 ml-4">
              <li className="flex gap-3">
                <span className="text-accent font-semibold min-w-fit">Personal Identification Information:</span>
                <span className="text-muted-foreground">
                  Your name, email address, and phone number when you submit them through our contact form.
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-accent font-semibold min-w-fit">Non-Personal Information:</span>
                <span className="text-muted-foreground">
                  We may collect browser type, operating system, and website usage data through cookies and analytics
                  tools to improve our website's user experience.
                </span>
              </li>
            </ul>
          </section>

          <section id="section-3" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.3s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">
              3. Client Data and Campaign Confidentiality
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              This is the cornerstone of our service. We understand the sensitive nature of your business data.
            </p>
            <div className="space-y-4 ml-4">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h3 className="font-semibold text-foreground mb-2">Strict Confidentiality</h3>
                <p className="text-muted-foreground">
                  All information provided by you ("The Client")—including but not limited to business strategies,
                  customer lists, financial data, keyword strategies, campaign analytics, and backend website access—is
                  treated as strictly confidential.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                <h3 className="font-semibold text-foreground mb-2">Non-Disclosure</h3>
                <p className="text-muted-foreground">
                  We will not share, sell, distribute, or otherwise disclose your confidential information to any third
                  party without your explicit, written consent, except as required by law.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-secondary/30 border border-border/50">
                <h3 className="font-semibold text-foreground mb-2">Data Usage</h3>
                <p className="text-muted-foreground">
                  Your data is used only for the purpose of planning, executing, and reporting on the digital marketing
                  and SEO services you have hired us to perform.
                </p>
              </div>
            </div>
          </section>

          <section id="section-4" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.35s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">4. How We Use Your Information</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              The information we collect is used solely for the following purposes:
            </p>
            <ul className="list-none space-y-2 ml-4">
              {[
                "To respond to your inquiries and project proposals.",
                "To provide and manage the services you have requested.",
                "To send invoices and process payments.",
                "To improve our website and service offerings.",
              ].map((item, idx) => (
                <li key={idx} className="flex items-start gap-3 text-muted-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>

          <section id="section-5" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">5. Data Security</h2>
            <p className="text-muted-foreground leading-relaxed">
              We implement a variety of security measures to maintain the safety of your personal and business
              information. We use industry-standard practices to protect your data from unauthorized access, alteration,
              or disclosure.
            </p>
          </section>

          <section id="section-6" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.45s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">6. Cookies</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our website may use "cookies" to enhance user experience. Cookies are small files placed on your
              computer's hard drive. You may choose to set your web browser to refuse cookies, though doing so may
              affect the functionality of some parts of our site.
            </p>
          </section>

          <section id="section-7" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.5s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">7. Third-Party Links</h2>
            <p className="text-muted-foreground leading-relaxed">
              Occasionally, we may include links to third-party websites (e.g., tools, resources). These third-party
              sites have separate and independent privacy policies. We, therefore, have no responsibility or liability
              for the content and activities of these linked sites.
            </p>
          </section>

          <section id="section-8" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.55s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">8. Your Consent</h2>
            <p className="text-muted-foreground leading-relaxed">
              By using our website and engaging our services, you consent to this Privacy Policy.
            </p>
          </section>

          <section id="section-9" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.6s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">9. Changes to This Policy</h2>
            <p className="text-muted-foreground leading-relaxed">
              We reserve the right to update this Privacy Policy at any time. Any modifications will be posted on this
              page. We encourage you to review this page periodically to stay informed about how we are protecting your
              information.
            </p>
          </section>

          <section id="section-10" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.65s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">10. Contact Us</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              If you have any questions regarding this Privacy Policy, please contact us via the information provided on
              our website's contact page.
            </p>
            <div className="p-6 rounded-xl bg-primary/5 border border-primary/20">
              <p className="text-muted-foreground">
                For inquiries about your privacy or our data practices, please use the contact form on our main website
                or reach out to us directly through email.
              </p>
            </div>
          </section>
        </div>

        {/* Last Updated */}
        <div
          className="mt-16 pt-8 border-t border-border text-center text-sm text-muted-foreground animate-fade-in"
          style={{ animationDelay: "0.7s" }}
        >
          <p>Last updated: November 2024</p>
        </div>
      </div>

      <Footer />
    </main>
  )
}
