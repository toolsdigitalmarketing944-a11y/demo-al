"use client"

import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ChevronRight, Code, BarChart3, PenTool, Users, Zap, Trophy } from "lucide-react"

export default function AboutPage() {
  const skills = [
    {
      icon: Code,
      title: "Search Engine Optimization",
      description:
        "Expertise in on-page, off-page, and technical SEO to improve search engine rankings, drive qualified organic traffic, and increase online visibility.",
    },
    {
      icon: BarChart3,
      title: "Paid Advertising",
      description:
        "Proficient in managing and optimizing high-performing campaigns on Google Ads and social media platforms to maximize ROI.",
    },
    {
      icon: PenTool,
      title: "Content Strategy & Marketing",
      description:
        "Skilled in developing and executing content plans that attract, engage, and convert target audiences.",
    },
    {
      icon: Users,
      title: "Social Media Management",
      description:
        "Experienced in building and nurturing online communities, managing brand reputation, and running targeted campaigns.",
    },
    {
      icon: Zap,
      title: "Email Marketing",
      description:
        "Capable of designing and implementing effective email funnels, newsletters, and automation sequences.",
    },
    {
      icon: Trophy,
      title: "Data Analysis & Reporting",
      description:
        "Using tools like Google Analytics to track KPIs, analyze data, and provide actionable insights for continuous improvement.",
    },
  ]

  const stats = [
    { number: "50+", label: "Projects Completed" },
    { number: "30+", label: "Happy Clients" },
    { number: "5+", label: "Years Experience" },
    { number: "99%", label: "Client Satisfaction" },
  ]

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        {/* Header */}
        <div className="mb-12 md:mb-20 animate-fade-in">
          <div className="flex items-center gap-2 mb-4 text-accent">
            <ChevronRight size={18} />
            <span className="text-sm md:text-base font-medium">Get to Know Me</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            About Nurullah
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl leading-relaxed">
            I am a results-driven digital marketer, passionate about helping businesses build their online presence and
            achieve measurable growth.
          </p>
        </div>

        {/* About Intro */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 mb-16 md:mb-24">
          <div className="animate-fade-in" style={{ animationDelay: "0.1s" }}>
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">My Approach</h2>
                <p className="text-muted-foreground leading-relaxed">
                  My approach combines data-driven strategy with creative execution to connect brands with their target
                  audiences in meaningful ways. I specialize in developing comprehensive digital strategies that not
                  only increase traffic and engagement but also drive conversions and deliver a strong return on
                  investment (ROI).
                </p>
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">My Philosophy</h2>
                <p className="text-muted-foreground leading-relaxed">
                  I thrive in dynamic environments and am dedicated to staying ahead of industry trends to ensure my
                  clients' success. Every campaign is tailored to meet unique business goals, and I believe in
                  transparent communication and measurable results.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            {stats.map((stat, idx) => (
              <div
                key={idx}
                className="p-6 md:p-8 rounded-2xl bg-gradient-to-br from-primary/10 via-secondary/20 to-accent/10 border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
              >
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
                  {stat.number}
                </div>
                <p className="text-sm md:text-base text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Skills Section */}
        <div className="mb-16 md:mb-24 animate-fade-in" style={{ animationDelay: "0.3s" }}>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Key Skills & Expertise</h2>
          <p className="text-muted-foreground mb-12 max-w-2xl">
            Here are the core competencies I use to help businesses succeed online:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, idx) => {
              const Icon = skill.icon
              return (
                <div
                  key={idx}
                  className="group p-6 md:p-8 rounded-2xl bg-secondary/30 border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 hover:bg-secondary/50 animate-fade-in"
                  style={{ animationDelay: `${0.35 + idx * 0.08}s` }}
                >
                  <Icon className="w-10 md:w-12 h-10 md:h-12 text-primary mb-4 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="text-lg md:text-xl font-bold text-foreground mb-3">{skill.title}</h3>
                  <p className="text-muted-foreground text-sm md:text-base leading-relaxed">{skill.description}</p>
                </div>
              )
            })}
          </div>
        </div>

        {/* CTA Section */}
        <div
          className="mt-16 md:mt-24 p-8 md:p-12 rounded-3xl bg-gradient-to-r from-primary/20 via-secondary/30 to-accent/20 border border-primary/30 text-center animate-fade-in"
          style={{ animationDelay: "0.7s" }}
        >
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Ready to Grow Your Business?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Let's work together to create a digital strategy that delivers real results. Get in touch today to discuss
            your project.
          </p>
          <a
            href="/#contact"
            className="inline-block px-8 md:px-10 py-3 md:py-4 bg-gradient-to-r from-primary to-accent hover:shadow-lg hover:shadow-primary/30 rounded-full font-semibold text-background transition-all duration-300 hover:scale-105"
          >
            Get In Touch
          </a>
        </div>
      </div>

      <Footer />
    </main>
  )
}
