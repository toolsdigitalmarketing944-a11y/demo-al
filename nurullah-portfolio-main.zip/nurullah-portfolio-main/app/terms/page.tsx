"use client"

import { useEffect, useState } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ChevronRight } from "lucide-react"

export default function TermsPage() {
  const [scrollProgress, setScrollProgress] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight
      const scrolled = window.scrollY
      setScrollProgress((scrolled / windowHeight) * 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const sections = [
    { id: 1, title: "Agreement to Terms" },
    { id: 2, title: "Scope of Services" },
    { id: 3, title: "Payment Terms" },
    { id: 4, title: "Client Responsibilities" },
    { id: 5, title: "Project Timelines and Delivery" },
    { id: 6, title: "Revisions and Scope Creep" },
    { id: 7, title: "Cancellation Policy" },
    { id: 8, title: "Intellectual Property and Portfolio Rights" },
    { id: 9, title: "Limitation of Liability" },
    { id: 10, title: "Changes to Terms" },
  ]

  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-primary via-accent to-primary"
        style={{ width: `${scrollProgress}%` }}
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        {/* Header */}
        <div className="mb-12 md:mb-16 animate-fade-in">
          <div className="flex items-center gap-2 mb-4 text-accent">
            <ChevronRight size={18} />
            <span className="text-sm md:text-base font-medium">Legal Documents</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            Terms & Conditions
          </h1>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl">
            Please read these terms carefully before engaging our services. Your use of our website and services
            constitutes acceptance of these terms.
          </p>
        </div>

        {/* Table of Contents */}
        <div
          className="mb-12 md:mb-16 p-6 rounded-2xl bg-secondary/30 border border-border/50 backdrop-blur-sm hover:border-primary/50 transition-all duration-300 animate-fade-in"
          style={{ animationDelay: "0.1s" }}
        >
          <h2 className="text-xl md:text-2xl font-semibold mb-6">Table of Contents</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {sections.map((section, index) => (
              <a
                key={section.id}
                href={`#section-${section.id}`}
                className="group flex items-center gap-2 p-3 rounded-lg hover:bg-primary/10 transition-all duration-200"
                style={{ animationDelay: `${0.15 + index * 0.05}s` }}
              >
                <span className="text-primary font-semibold min-w-fit">{section.id}.</span>
                <span className="text-muted-foreground group-hover:text-foreground transition-colors">
                  {section.title}
                </span>
              </a>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="space-y-10 md:space-y-14">
          <section id="section-1" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">1. Agreement to Terms</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Welcome! By accessing this website and engaging our services, you ("The Client") agree to be bound by
              these Terms and Conditions ("Terms"), all applicable laws, and regulations. If you do not agree with any
              of these terms, you are prohibited from using or accessing this site.
            </p>
          </section>

          <section id="section-2" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.25s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">2. Scope of Services</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We ("The Service Provider") offer specialized digital marketing and web services. Our expertise includes,
              but is not limited to:
            </p>
            <ul className="list-none space-y-2 mb-4 ml-4">
              {[
                "Search Engine Optimization (SEO)",
                "Strategic Backlink Building",
                "Social Media Marketing (SMM)",
                "Paid Marketing (PPC & Ad Campaigns)",
                "Website Design and Development",
                "Digital Marketing Consultancy",
              ].map((item, idx) => (
                <li key={idx} className="flex items-start gap-3 text-muted-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <p className="text-muted-foreground leading-relaxed">
              All services will be explicitly detailed in a formal proposal or service agreement provided to the Client
              before the commencement of any project.
            </p>
          </section>

          <section id="section-3" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.3s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">3. Payment Terms</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Our payment structure is designed to ensure a mutual commitment to the project's success:
            </p>
            <div className="space-y-4 ml-4 mb-4">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h3 className="font-semibold text-foreground mb-2">Advance Payment</h3>
                <p className="text-muted-foreground">
                  A non-refundable advance payment of sixty percent (60%) of the total project fee is required before
                  any work commences. This payment secures your project in our schedule and covers initial project
                  resources.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                <h3 className="font-semibold text-foreground mb-2">Final Payment</h3>
                <p className="text-muted-foreground">
                  The remaining forty percent (40%) balance is due upon project completion and prior to the final
                  delivery of work, files, or administrative access.
                </p>
              </div>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Payments are to be made via the methods specified in the project invoice. Failure to make the final
              payment will result in a delay in project delivery.
            </p>
          </section>

          <section id="section-4" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.35s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">4. Client Responsibilities</h2>
            <p className="text-muted-foreground leading-relaxed">
              The Client agrees to provide all necessary information, content (text, images, brand guidelines), and
              access (to website backends, analytics, etc.) required for the Service Provider to complete the project.
              Delays in receiving these materials may result in a corresponding delay in the project completion
              timeline.
            </p>
          </section>

          <section id="section-5" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">5. Project Timelines and Delivery</h2>
            <p className="text-muted-foreground leading-relaxed">
              An estimated project timeline will be provided in the service agreement. While we strive to meet all
              deadlines, these timelines are estimates and can be affected by client feedback, revision requests, or
              unforeseen technical challenges. We will maintain clear communication regarding the project's status.
            </p>
          </section>

          <section id="section-6" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.45s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">6. Revisions and Scope Creep</h2>
            <p className="text-muted-foreground leading-relaxed">
              The initial project proposal will outline a specific number of revisions (e.g., two or three rounds). Any
              requests for revisions or additional features outside the original agreed-upon scope ("scope creep") will
              be assessed and may incur additional charges and timeline extensions, which will be communicated to the
              Client for approval.
            </p>
          </section>

          <section id="section-7" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.5s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">7. Cancellation Policy</h2>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-secondary/30 border border-border/50">
                <h3 className="font-semibold text-foreground mb-2">By the Client</h3>
                <p className="text-muted-foreground">
                  If the Client chooses to cancel the project after work has begun, the 60% advance payment is
                  non-refundable.
                </p>
              </div>
              <div className="p-4 rounded-lg bg-secondary/30 border border-border/50">
                <h3 className="font-semibold text-foreground mb-2">By the Service Provider</h3>
                <p className="text-muted-foreground">
                  We reserve the right to cancel a project if the Client is unresponsive, fails to provide necessary
                  materials, or breaches the terms of our agreement.
                </p>
              </div>
            </div>
          </section>

          <section id="section-8" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.55s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">
              8. Intellectual Property and Portfolio Rights
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Upon receipt of the final payment, the Client will own the intellectual property for the finalized and
              delivered work.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              The Service Provider retains the right to display the completed project and a description of the work in
              our personal portfolio, website, and social media channels for marketing purposes. Client confidentiality
              (as defined in our Privacy Policy) will be strictly maintained.
            </p>
          </section>

          <section id="section-9" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.6s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">9. Limitation of Liability</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              The Service Provider will not be liable for any indirect, special, or consequential damages, including any
              loss of revenue, profits, or data, arising in connection with our services or these Terms.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              While we employ best practices in SEO and marketing, we cannot guarantee specific rankings, lead volumes,
              or search engine results, as these are dependent on factors beyond our control (e.g., search engine
              algorithm changes).
            </p>
          </section>

          <section id="section-10" className="scroll-mt-20 animate-fade-in" style={{ animationDelay: "0.65s" }}>
            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">10. Changes to Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              We reserve the right to modify these Terms at any time. Any changes will be posted on this page, and your
              continued use of the site and our services will constitute acceptance of those changes.
            </p>
          </section>
        </div>

        {/* Last Updated */}
        <div
          className="mt-16 pt-8 border-t border-border text-center text-sm text-muted-foreground animate-fade-in"
          style={{ animationDelay: "0.7s" }}
        >
          <p>Last updated: November 2024</p>
        </div>
      </div>

      <Footer />
    </main>
  )
}
