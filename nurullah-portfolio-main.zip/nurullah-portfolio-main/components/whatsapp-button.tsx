"use client"

import { MessageCircle } from "lucide-react"
import { useState, useEffect } from "react"

export function WhatsAppButton() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 300) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener("scroll", toggleVisibility)
    return () => window.removeEventListener("scroll", toggleVisibility)
  }, [])
  

  const whatsappNumber = "your-whatsapp-number" // Replace with your WhatsApp number
  const whatsappMessage = "Hi! I would like to discuss a digital marketing project with you."
  const whatsappLink = `https://wa.me/${8801333387179}?text=${encodeURIComponent(whatsappMessage)}`

  return (
    <>
      {isVisible && (
        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-8 right-8 z-50 group"
          aria-label="Contact via WhatsApp"
        >
          <div className="relative">
            {/* Animated background pulse */}
            <div className="absolute inset-0 rounded-full bg-green-500/30 animate-pulse"></div>

            {/* Main button */}
            <button className="relative w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-r from-green-400 to-green-600 text-white shadow-lg hover:shadow-2xl transform hover:scale-110 transition-all duration-300 flex items-center justify-center group-hover:rotate-12">
              <MessageCircle size={28} className="md:w-8 md:h-8" />
            </button>

            {/* Tooltip */}
            <div className="absolute right-16 bottom-1/2 transform translate-y-1/2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-300 shadow-lg">
              Chat with us on WhatsApp
              <div className="absolute left-full top-1/2 transform -translate-y-1/2 w-2 h-2 bg-gray-900"></div>
            </div>
          </div>
        </a>
      )}
    </>
  )
}
