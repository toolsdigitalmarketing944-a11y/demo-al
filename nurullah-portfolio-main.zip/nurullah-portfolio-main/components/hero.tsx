"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, TrendingUp, Users, Zap } from "lucide-react"
import { TypingAnimation } from "./typing-animation"

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = heroRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16 md:pt-20"
    >
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 md:w-96 h-64 md:h-96 bg-primary/20 rounded-full blur-3xl animate-pulse-glow" />
        <div
          className="absolute bottom-1/4 right-1/4 w-64 md:w-96 h-64 md:h-96 bg-accent/20 rounded-full blur-3xl animate-pulse-glow"
          style={{ animationDelay: "1.5s" }}
        />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 md:w-[600px] h-96 md:h-[600px] bg-chart-3/10 rounded-full blur-3xl animate-float" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          <div className="animate-on-scroll opacity-0 mb-8 md:mb-12">
            <TypingAnimation />
          </div>

          <p
            className="animate-on-scroll opacity-0 text-base md:text-lg lg:text-xl text-muted-foreground mb-6 md:mb-8 max-w-3xl mx-auto text-balance leading-relaxed"
            style={{ animationDelay: "0.2s" }}
          >
            I transform brands and drive growth through data-driven digital marketing strategies. From SEO optimization
            to social media dominance, I help businesses scale their online presence and achieve measurable results.
          </p>

          <div
            className="animate-on-scroll opacity-0 flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-12 md:mb-16"
            style={{ animationDelay: "0.3s" }}
          >
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-base md:text-lg group w-full sm:w-auto">
              Let's Work Together
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-base md:text-lg border-border hover:bg-secondary bg-transparent w-full sm:w-auto"
            >
              View My Portfolio
            </Button>
          </div>

          <div
            className="animate-on-scroll opacity-0 grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-8 max-w-3xl mx-auto"
            style={{ animationDelay: "0.4s" }}
          >
            <div className="group hover:scale-105 transition-all duration-300 p-4 md:p-6 rounded-lg hover:bg-secondary/20 hover:border hover:border-primary/30">
              <div className="flex flex-col md:flex-row items-center justify-center gap-2 mb-2">
                <TrendingUp className="text-primary" size={24} />
                <span className="text-2xl md:text-3xl lg:text-4xl font-bold">300%</span>
              </div>
              <p className="text-xs md:text-sm text-muted-foreground">Average ROI Increase</p>
            </div>
            <div className="group hover:scale-105 transition-all duration-300 p-4 md:p-6 rounded-lg hover:bg-secondary/20 hover:border hover:border-accent/30">
              <div className="flex flex-col md:flex-row items-center justify-center gap-2 mb-2">
                <Users className="text-accent" size={24} />
                <span className="text-2xl md:text-3xl lg:text-4xl font-bold">150+</span>
              </div>
              <p className="text-xs md:text-sm text-muted-foreground">Campaigns Managed</p>
            </div>
            <div className="group hover:scale-105 transition-all duration-300 p-4 md:p-6 rounded-lg hover:bg-secondary/20 hover:border hover:border-chart-3/30">
              <div className="flex flex-col md:flex-row items-center justify-center gap-2 mb-2">
                <Zap className="text-chart-3" size={24} />
                <span className="text-2xl md:text-3xl lg:text-4xl font-bold">98%</span>
              </div>
              <p className="text-xs md:text-sm text-muted-foreground">Client Satisfaction</p>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-primary rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  )
}
