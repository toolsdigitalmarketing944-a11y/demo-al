"use client"

import { useEffect, useState } from "react"
import { CheckCircle, X } from "lucide-react"

interface SuccessModalProps {
  isOpen: boolean
  onClose: () => void
}

export function SuccessModal({ isOpen, onClose }: SuccessModalProps) {
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setAnimate(true)
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
        style={{
          animation: animate ? "fadeIn 0.3s ease-in-out" : "fadeOut 0.3s ease-in-out",
        }}
      />

      {/* Modal */}
      <div
        className="relative bg-card border border-primary/30 rounded-2xl p-8 md:p-12 max-w-md w-full shadow-2xl"
        style={{
          animation: animate ? "slideUp 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)" : "slideDown 0.3s ease-in-out",
        }}
      >
        <button
          onClick={onClose}
          className="absolute top-4 md:top-6 right-4 md:right-6 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="flex flex-col items-center text-center">
          {/* Success Icon */}
          <div className="mb-6 relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-full blur-xl opacity-50 animate-pulse" />
            <CheckCircle className="w-20 h-20 md:w-24 md:h-24 text-primary relative animate-bounce" />
          </div>

          {/* Title */}
          <h2 className="text-2xl md:text-3xl font-bold mb-3 text-foreground">Message Sent Successfully!</h2>

          {/* Description */}
          <p className="text-muted-foreground mb-6 text-base leading-relaxed">
            Thank you for reaching out! We've received your message and will get back to you within 24 hours. Check your
            email for confirmation.
          </p>

          {/* Success Details */}
          <div className="w-full bg-primary/10 border border-primary/30 rounded-lg p-4 mb-6">
            <p className="text-sm text-primary font-semibold">✓ Confirmation email sent</p>
            <p className="text-xs text-muted-foreground mt-1">We'll be in touch shortly</p>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105"
          >
            Got it!
          </button>
        </div>

        <style jsx>{`
          @keyframes slideUp {
            from {
              opacity: 0;
              transform: translateY(20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          @keyframes slideDown {
            from {
              opacity: 1;
              transform: translateY(0);
            }
            to {
              opacity: 0;
              transform: translateY(20px);
            }
          }

          @keyframes fadeIn {
            from {
              opacity: 0;
            }
            to {
              opacity: 1;
            }
          }

          @keyframes fadeOut {
            from {
              opacity: 1;
            }
            to {
              opacity: 0;
            }
          }

          @keyframes bounce {
            0%,
            100% {
              transform: translateY(0);
            }
            50% {
              transform: translateY(-10px);
            }
          }

          .animate-bounce {
            animation: bounce 1s infinite;
          }
        `}</style>
      </div>
    </div>
  )
}
