"use client"

import { useEffect, useState } from "react"

export function TypingAnimation() {
  const [displayText, setDisplayText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)
  const [loopNum, setLoopNum] = useState(0)

  const textArray = ["Hi, I am Nurullah", "A digital marketer"]
  const typingSpeed = 50
  const deletingSpeed = 30
  const delayBetweenLoops = 2000

  useEffect(() => {
    let timer: NodeJS.Timeout

    const handleTyping = () => {
      const currentText = textArray[loopNum % textArray.length]

      if (!isDeleting) {
        if (displayText.length < currentText.length) {
          setDisplayText(currentText.substring(0, displayText.length + 1))
          timer = setTimeout(handleTyping, typingSpeed)
        } else {
          timer = setTimeout(() => setIsDeleting(true), delayBetweenLoops)
        }
      } else {
        if (displayText.length > 0) {
          setDisplayText(currentText.substring(0, displayText.length - 1))
          timer = setTimeout(handleTyping, deletingSpeed)
        } else {
          setIsDeleting(false)
          setLoopNum(loopNum + 1)
          timer = setTimeout(handleTyping, 500)
        }
      }
    }

    timer = setTimeout(handleTyping, typingSpeed)
    return () => clearTimeout(timer)
  }, [displayText, isDeleting, loopNum])

  return (
    <div className="min-h-[120px] flex items-center justify-center">
      <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-center">
        <span className="bg-gradient-to-r from-primary via-accent to-chart-3 bg-clip-text text-transparent">
          {displayText}
        </span>
        <span className="animate-pulse text-primary">|</span>
      </h1>
    </div>
  )
}
