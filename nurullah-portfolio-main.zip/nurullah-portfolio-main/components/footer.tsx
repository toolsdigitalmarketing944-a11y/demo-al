import { Facebook, Instagram, Linkedin, Twitter, Youtube, MessageCircle } from "lucide-react"



export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-border bg-secondary/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-6 md:mb-8">
          {/* Brand */}
          <div>
            <h3 className="text-lg md:text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-3 md:mb-4">
              DigitalPro
            </h3>
            <p className="text-xs md:text-sm text-muted-foreground mb-4">
              Transforming businesses through data-driven digital marketing solutions.
            </p>
            <div className="flex gap-3 md:gap-4">
              <a
                href="https://www.facebook.com/nurullahalamin2"
                className="text-muted-foreground hover:text-primary transition-colors hover:scale-110 transform duration-200"
              >
                <Facebook size={18} />
              </a>
              
              <a
                href="https://www.linkedin.com/in/nurullahal-amin"
                className="text-muted-foreground hover:text-primary transition-colors hover:scale-110 transform duration-200"
              >
                <Linkedin size={18} />
              </a>
              
              <a
                href="https://wa.me/8801333387179"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors hover:scale-110 transform duration-200"
              >
                <MessageCircle size={18} />
              </a>
              
              
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-sm md:text-base mb-3 md:mb-4">Services</h4>
            <ul className="space-y-1 md:space-y-2 text-xs md:text-sm text-muted-foreground">
              <li>
                <a
                  href="#services"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  SEO Optimization
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Social Media
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Paid Advertising
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Content Marketing
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Automation
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-sm md:text-base mb-3 md:mb-4">Company</h4>
            <ul className="space-y-1 md:space-y-2 text-xs md:text-sm text-muted-foreground">
              <li>
                <a
                  href="/about"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#portfolio"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Portfolio
                </a>
              </li>
              
              
              <li>
                <a
                  href="#contact"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-sm md:text-base mb-3 md:mb-4">Legal</h4>
            <ul className="space-y-1 md:space-y-2 text-xs md:text-sm text-muted-foreground">
              <li>
                <a
                  href="/privacy"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="/terms"
                  className="hover:text-foreground transition-colors hover:translate-x-1 transform duration-200 inline-block"
                >
                  Terms of Service
                </a>
              </li>
              
              
            </ul>
          </div>
        </div>

        <div className="pt-6 md:pt-8 border-t border-border text-center text-xs md:text-sm text-muted-foreground">
          <p>&copy; {currentYear} Digi-Expert. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
