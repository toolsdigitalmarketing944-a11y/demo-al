"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, Facebook, Instagram, Youtube, Music } from "lucide-react"

const pricingData = {
  facebook: [
    {
      name: "100 Followers",
      price: "$9.99",
      description: "Boost your Facebook presence",
      features: ["Real & Active Users", "Instant Delivery", "24/7 Support", "No Password Required"],
    },
    {
      name: "1K Post Likes",
      price: "$14.99",
      description: "Increase engagement on your posts",
      features: ["High-Quality Likes", "Fast Delivery", "Lifetime Guarantee", "Safe & Secure"],
      popular: true,
    },
    {
      name: "500 Comments",
      price: "$29.99",
      description: "Get authentic comments",
      features: ["Real Comments", "Custom Messages", "Natural Engagement", "Drip-Feed Available"],
    },
    {
      name: "1K Shares",
      price: "$24.99",
      description: "Expand your reach",
      features: ["Organic Shares", "Worldwide Audience", "Instant Start", "Money-Back Guarantee"],
    },
    {
      name: "5K Video Views",
      price: "$19.99",
      description: "Boost video visibility",
      features: ["Real Views", "High Retention", "Fast Delivery", "Safe Method"],
    },
    {
      name: "1K Group Members",
      price: "$49.99",
      description: "Grow your community",
      features: ["Active Members", "Targeted Audience", "Gradual Delivery", "Lifetime Support"],
    },
  ],
  instagram: [
    {
      name: "500 Followers",
      price: "$12.99",
      description: "Grow your Instagram following",
      features: ["Real Accounts", "Instant Start", "No Drop Guarantee", "24/7 Support"],
    },
    {
      name: "2K Likes",
      price: "$16.99",
      description: "Boost post engagement",
      features: ["High-Quality Likes", "Fast Delivery", "Safe & Secure", "Lifetime Warranty"],
      popular: true,
    },
    {
      name: "10K Views",
      price: "$14.99",
      description: "Increase video visibility",
      features: ["Real Views", "High Retention", "Instant Delivery", "Money-Back Guarantee"],
    },
    {
      name: "100 Comments",
      price: "$24.99",
      description: "Get authentic engagement",
      features: ["Custom Comments", "Real Users", "Natural Delivery", "Safe Method"],
    },
    {
      name: "1K Story Views",
      price: "$9.99",
      description: "Boost story visibility",
      features: ["Real Views", "Fast Delivery", "24/7 Support", "No Password Needed"],
    },
    {
      name: "500 Saves",
      price: "$19.99",
      description: "Increase content saves",
      features: ["Real Saves", "Organic Growth", "Instant Start", "Lifetime Support"],
    },
  ],
  youtube: [
    {
      name: "1K Subscribers",
      price: "$49.99",
      description: "Grow your channel",
      features: ["Real Subscribers", "Monetization Safe", "Gradual Delivery", "Lifetime Guarantee"],
    },
    {
      name: "10K Views",
      price: "$29.99",
      description: "Boost video visibility",
      features: ["High Retention Views", "Real & Active", "Fast Delivery", "Safe Method"],
      popular: true,
    },
    {
      name: "4K Watch Hours",
      price: "$199.99",
      description: "Monetization requirement",
      features: ["Real Watch Time", "Monetization Safe", "Gradual Delivery", "Money-Back Guarantee"],
    },
    {
      name: "500 Likes",
      price: "$19.99",
      description: "Increase engagement",
      features: ["Real Likes", "Fast Delivery", "Safe & Secure", "24/7 Support"],
    },
    {
      name: "100 Comments",
      price: "$34.99",
      description: "Get authentic feedback",
      features: ["Custom Comments", "Real Users", "Natural Engagement", "Lifetime Support"],
    },
    {
      name: "1K Shares",
      price: "$24.99",
      description: "Expand your reach",
      features: ["Organic Shares", "Worldwide Audience", "Instant Start", "Safe Method"],
    },
  ],
  tiktok: [
    {
      name: "1K Followers",
      price: "$14.99",
      description: "Grow your TikTok presence",
      features: ["Real Followers", "Instant Start", "No Drop Guarantee", "24/7 Support"],
    },
    {
      name: "10K Views",
      price: "$9.99",
      description: "Boost video visibility",
      features: ["High-Quality Views", "Fast Delivery", "Safe & Secure", "Money-Back Guarantee"],
      popular: true,
    },
    {
      name: "2K Likes",
      price: "$12.99",
      description: "Increase engagement",
      features: ["Real Likes", "Instant Delivery", "Lifetime Warranty", "Safe Method"],
    },
    {
      name: "500 Comments",
      price: "$29.99",
      description: "Get authentic comments",
      features: ["Custom Comments", "Real Users", "Natural Delivery", "24/7 Support"],
    },
    {
      name: "5K Live Views",
      price: "$39.99",
      description: "Boost live streams",
      features: ["Real Viewers", "Instant Delivery", "Active Engagement", "Safe & Secure"],
    },
    {
      name: "1K Shares",
      price: "$19.99",
      description: "Expand your reach",
      features: ["Organic Shares", "Worldwide Audience", "Instant Start", "Lifetime Support"],
    },
  ],
}

export function Pricing() {
  const [activePlatform, setActivePlatform] = useState("facebook")
  const pricingRef = useRef<HTMLDivElement>(null)

  const scrollToContact = () => {
    const contactSection = document.getElementById("contact")
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = pricingRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [activePlatform])

  const platforms = [
    { id: "facebook", name: "Facebook", icon: Facebook, color: "from-blue-500 to-blue-600" },
    { id: "instagram", name: "Instagram", icon: Instagram, color: "from-pink-500 to-purple-600" },
    { id: "youtube", name: "YouTube", icon: Youtube, color: "from-red-500 to-red-600" },
    { id: "tiktok", name: "TikTok", icon: Music, color: "from-cyan-400 to-pink-500" },
  ]

  return (
    <section id="pricing" ref={pricingRef} className="py-16 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/20 to-background" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-10 md:mb-12">
          <h2 className="animate-on-scroll opacity-0 text-2xl md:text-4xl lg:text-5xl font-bold mb-3 md:mb-4">
            Social Media{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Pricing</span>
          </h2>
          <p
            className="animate-on-scroll opacity-0 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto"
            style={{ animationDelay: "0.1s" }}
          >
            Choose your platform and boost your social media presence
          </p>
        </div>

        <div
          className="animate-on-scroll opacity-0 flex flex-wrap justify-center gap-2 md:gap-4 mb-10 md:mb-12"
          style={{ animationDelay: "0.2s" }}
        >
          {platforms.map((platform) => {
            const Icon = platform.icon
            return (
              <Button
                key={platform.id}
                onClick={() => setActivePlatform(platform.id)}
                className={`group relative px-4 md:px-6 py-5 md:py-6 text-xs md:text-base font-medium transition-all duration-300 ${
                  activePlatform === platform.id
                    ? `bg-gradient-to-r ${platform.color} text-white shadow-lg scale-105 hover:shadow-xl`
                    : "bg-secondary/50 text-muted-foreground hover:bg-secondary hover:scale-105"
                }`}
              >
                <Icon className="mr-1 md:mr-2 inline-block" size={18} />
                <span className="hidden sm:inline">{platform.name}</span>
                <span className="sm:hidden">{platform.name.slice(0, 3)}</span>
                {activePlatform === platform.id && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent rounded-md animate-pulse" />
                )}
              </Button>
            )
          })}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
          {pricingData[activePlatform as keyof typeof pricingData].map((plan, index) => (
            <Card
              key={plan.name}
              className={`animate-on-scroll opacity-0 relative ${
                plan.popular ? "border-primary shadow-lg shadow-primary/20 sm:scale-105" : "border-border"
              } bg-card/50 backdrop-blur-sm hover:scale-105 transition-all duration-300`}
              style={{ animationDelay: `${0.1 * (index + 1)}s` }}
            >
              {plan.popular && (
                <div className="absolute -top-3 md:-top-4 left-1/2 -translate-x-1/2 px-3 md:px-4 py-1 bg-gradient-to-r from-primary to-accent rounded-full text-xs md:text-sm font-medium text-white">
                  Most Popular
                </div>
              )}
              <CardHeader>
                <CardTitle className="text-lg md:text-2xl">{plan.name}</CardTitle>
                <CardDescription className="text-xs md:text-sm text-muted-foreground">
                  {plan.description}
                </CardDescription>
                <div className="mt-3 md:mt-4">
                  <span className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    {plan.price}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 md:space-y-3 mb-4 md:mb-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2">
                      <Check className="text-primary mt-0.5 flex-shrink-0" size={18} />
                      <span className="text-xs md:text-sm text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  onClick={scrollToContact}
                  className={`w-full text-sm md:text-base ${
                    plan.popular
                      ? "bg-gradient-to-r from-primary to-accent hover:opacity-90"
                      : "bg-secondary hover:bg-secondary/80"
                  }`}
                >
                  Order Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
