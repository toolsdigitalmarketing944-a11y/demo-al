"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Share2, Target, FileText, Workflow, Mail } from "lucide-react"

const services = [
  {
    icon: Search,
    title: "SEO & GEO Optimization",
    description:
      "AI-powered SEO services, technical audits, local SEO, and link building to boost your search rankings.",
    features: ["Technical SEO", "Local SEO", "Link Building", "Content Optimization"],
    color: "from-primary to-primary/50",
  },
  {
    icon: Share2,
    title: "Social Media Management",
    description:
      "Comprehensive social media strategy, content creation, and community management across all platforms.",
    features: ["Content Strategy", "Community Management", "Brand Growth", "Analytics"],
    color: "from-accent to-accent/50",
  },
  {
    icon: Target,
    title: "Paid Media & Advertising",
    description:
      "Strategic ad campaigns on Google, Meta, LinkedIn, and TikTok with advanced targeting and optimization.",
    features: ["Google Ads", "Meta Ads", "Retargeting", "Conversion Tracking"],
    color: "from-chart-3 to-chart-3/50",
  },
  {
    icon: FileText,
    title: "Content Marketing",
    description:
      "SEO-optimized content creation, blog writing, and content distribution to attract and educate your audience.",
    features: ["Blog Writing", "SEO Content", "Content Strategy", "CRO"],
    color: "from-chart-4 to-chart-4/50",
  },
  {
    icon: Workflow,
    title: "Marketing Automation",
    description: "CRM setup, automated email flows, lead nurturing, and sales pipeline optimization to save time.",
    features: ["CRM Integration", "Email Automation", "Lead Scoring", "Pipeline Management"],
    color: "from-chart-5 to-chart-5/50",
  },
  {
    icon: Mail,
    title: "Cold Email & B2B Outreach",
    description: "Targeted lead generation, personalized cold emails, and multi-channel outreach for B2B sales.",
    features: ["Lead Generation", "Email Sequences", "LinkedIn Outreach", "Deliverability"],
    color: "from-primary to-accent",
  },
]

export function Services() {
  const servicesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = servicesRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section id="services" ref={servicesRef} className="py-16 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/20 to-background" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="animate-on-scroll opacity-0 text-2xl md:text-4xl lg:text-5xl font-bold mb-3 md:mb-4">
            Our <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Services</span>
          </h2>
          <p
            className="animate-on-scroll opacity-0 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto"
            style={{ animationDelay: "0.1s" }}
          >
            Comprehensive digital marketing solutions tailored to your business needs
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
          {services.map((service, index) => (
            <Card
              key={service.title}
              className="animate-on-scroll opacity-0 group hover:scale-105 transition-all duration-300 bg-card/50 backdrop-blur-sm border-border hover:border-primary/50 hover:shadow-lg hover:shadow-primary/20 cursor-pointer"
              style={{ animationDelay: `${0.1 * (index + 1)}s` }}
            >
              <CardHeader>
                <div
                  className={`w-12 h-12 rounded-lg bg-gradient-to-br ${service.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
                >
                  <service.icon className="text-white" size={24} />
                </div>
                <CardTitle className="text-lg md:text-xl mb-2">{service.title}</CardTitle>
                <CardDescription className="text-sm text-muted-foreground">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li
                      key={feature}
                      className="flex items-center text-xs md:text-sm text-muted-foreground opacity-0 animate-fade-in-up"
                      style={{ animationDelay: `${0.1 * idx}s` }}
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
