"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const categories = ["All", "SEO", "Social Media", "Paid Ads", "Content", "Automation"]

const portfolioItems = [
  {
    id: 1,
    title: "E-commerce SEO Campaign",
    category: "SEO",
    description: "300% increase in organic traffic",
    image: "/ecommerce-analytics-dashboard.jpg",
    stats: { metric: "Traffic", value: "+300%" },
  },
  {
    id: 2,
    title: "Social Media Growth",
    category: "Social Media",
    description: "50K+ followers in 6 months",
    image: "/social-media-engagement-metrics.jpg",
    stats: { metric: "Followers", value: "50K+" },
  },
  {
    id: 3,
    title: "Google Ads Campaign",
    category: "Paid Ads",
    description: "5x ROAS for SaaS client",
    image: "/google-ads-dashboard-performance.jpg",
    stats: { metric: "ROAS", value: "5x" },
  },
  {
    id: 4,
    title: "Content Marketing Strategy",
    category: "Content",
    description: "1M+ monthly blog views",
    image: "/blog-content-analytics.jpg",
    stats: { metric: "Views", value: "1M+" },
  },
  {
    id: 5,
    title: "Marketing Automation",
    category: "Automation",
    description: "80% time saved on lead nurturing",
    image: "/marketing-automation-workflow.jpg",
    stats: { metric: "Time Saved", value: "80%" },
  },
  {
    id: 6,
    title: "B2B Lead Generation",
    category: "SEO",
    description: "500+ qualified leads per month",
    image: "/b2b-lead-generation-dashboard.jpg",
    stats: { metric: "Leads", value: "500+" },
  },
]

export function Portfolio() {
  const [activeCategory, setActiveCategory] = useState("All")
  const portfolioRef = useRef<HTMLDivElement>(null)

  const filteredItems =
    activeCategory === "All" ? portfolioItems : portfolioItems.filter((item) => item.category === activeCategory)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = portfolioRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [activeCategory])

  return (
    <section id="portfolio" ref={portfolioRef} className="py-16 md:py-32 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10 md:mb-12">
          <h2 className="animate-on-scroll opacity-0 text-2xl md:text-4xl lg:text-5xl font-bold mb-3 md:mb-4">
            Our <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Portfolio</span>
          </h2>
          <p
            className="animate-on-scroll opacity-0 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-6 md:mb-8"
            style={{ animationDelay: "0.1s" }}
          >
            Real results from real clients across various industries
          </p>

          <div
            className="animate-on-scroll opacity-0 flex flex-wrap justify-center gap-2 md:gap-3"
            style={{ animationDelay: "0.2s" }}
          >
            {categories.map((category) => (
              <Button
                key={category}
                variant={activeCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveCategory(category)}
                className={`text-xs md:text-sm ${activeCategory === category ? "bg-primary hover:bg-primary/90" : ""}`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
          {filteredItems.map((item, index) => (
            <Card
              key={item.id}
              className="animate-on-scroll opacity-0 group overflow-hidden bg-card/50 backdrop-blur-sm border-border hover:border-primary/50 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/20 cursor-pointer"
              style={{ animationDelay: `${0.1 * (index + 1)}s` }}
            >
              <div className="relative overflow-hidden h-40 md:h-48">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3 md:p-4">
                  <div className="text-xs md:text-sm font-medium text-primary">{item.category}</div>
                </div>
              </div>
              <CardContent className="p-4 md:p-6">
                <h3 className="text-base md:text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-xs md:text-sm text-muted-foreground mb-4">{item.description}</p>
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <span className="text-xs md:text-sm text-muted-foreground">{item.stats.metric}</span>
                  <span className="text-xl md:text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    {item.stats.value}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
