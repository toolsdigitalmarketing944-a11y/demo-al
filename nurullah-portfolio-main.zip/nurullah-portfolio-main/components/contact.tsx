"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin } from "lucide-react"
import { SuccessModal } from "./success-modal"

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [submitError, setSubmitError] = useState<string | null>(null)
  const contactRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = contactRef.current?.querySelectorAll(".animate-on-scroll")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setSubmitError(null)

    try {
      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) {
        throw new Error("Failed to send email")
      }

      setShowSuccessModal(true)
      setFormData({ name: "", email: "", company: "", message: "" })
    } catch (error) {
      console.error("Error:", error)
      setSubmitError("Failed to send message. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <section id="contact" ref={contactRef} className="py-20 md:py-40 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Header */}
          <div className="text-center mb-16 md:mb-20">
            <h2 className="animate-on-scroll opacity-0 text-3xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6">
              Let's Create Something{" "}
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                Amazing
              </span>
            </h2>
            <p
              className="animate-on-scroll opacity-0 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto"
              style={{ animationDelay: "0.1s" }}
            >
              Tell us about your project and let's discuss how we can help your business grow
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto">
            {/* Contact Info Cards */}
            <div className="space-y-4 md:space-y-6 lg:col-span-1">
              <div
                className="animate-on-scroll opacity-0 bg-card/50 backdrop-blur-sm border border-primary/20 rounded-xl p-6 hover:border-primary/50 hover:bg-card/80 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
                style={{ animationDelay: "0.2s" }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center mb-4">
                  <Mail className="text-white" size={24} />
                </div>
                <h3 className="font-semibold text-lg mb-2">Email</h3>
                <p className="text-sm text-muted-foreground">alaminnurullah@gmail.com</p>
              </div>

              <div
                className="animate-on-scroll opacity-0 bg-card/50 backdrop-blur-sm border border-accent/20 rounded-xl p-6 hover:border-accent/50 hover:bg-card/80 transition-all duration-300 hover:shadow-lg hover:shadow-accent/20"
                style={{ animationDelay: "0.3s" }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center mb-4">
                  <Phone className="text-white" size={24} />
                </div>
                <h3 className="font-semibold text-lg mb-2">Phone</h3>
                <p className="text-sm text-muted-foreground">+880 1312-898303</p>
              </div>

              <div
                className="animate-on-scroll opacity-0 bg-card/50 backdrop-blur-sm border border-chart-3/20 rounded-xl p-6 hover:border-chart-3/50 hover:bg-card/80 transition-all duration-300 hover:shadow-lg hover:shadow-chart-3/20"
                style={{ animationDelay: "0.4s" }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-chart-3 to-chart-3/50 flex items-center justify-center mb-4">
                  <MapPin className="text-white" size={24} />
                </div>
                <h3 className="font-semibold text-lg mb-2">Location</h3>
                <p className="text-sm text-muted-foreground">Dhaka, Bangladesh</p>
              </div>
            </div>

            {/* Contact Form */}
            <div
              className="animate-on-scroll opacity-0 lg:col-span-2 bg-card/50 backdrop-blur-sm border border-primary/20 rounded-2xl p-8 md:p-10"
              style={{ animationDelay: "0.5s" }}
            >
              <h3 className="text-2xl md:text-3xl font-bold mb-2">Tell us about a project</h3>
              <p className="text-muted-foreground mb-8">
                Share your project details and we'll get back to you within 24 hours
              </p>

              {submitError && (
                <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm flex items-start gap-3">
                  <span className="text-lg mt-0.5">✗</span>
                  <span>{submitError}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Name and Email Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Name</label>
                    <Input
                      placeholder="Your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      disabled={isLoading}
                      className="bg-background/50 border-primary/20 focus:border-primary text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-foreground">Email</label>
                    <Input
                      type="email"
                      placeholder="your.email@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      disabled={isLoading}
                      className="bg-background/50 border-primary/20 focus:border-primary text-base"
                    />
                  </div>
                </div>

                {/* Company */}
                <div>
                  <label className="block text-sm font-medium mb-2 text-foreground">Company</label>
                  <Input
                    placeholder="Your company name"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    disabled={isLoading}
                    className="bg-background/50 border-primary/20 focus:border-primary text-base"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2 text-foreground">Project Details</label>
                  <Textarea
                    placeholder="Describe your project, goals, current challenges, and what you're looking to achieve..."
                    rows={8}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                    disabled={isLoading}
                    className="bg-background/50 border-primary/20 focus:border-primary text-base resize-none"
                  />
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-10 md:h-11 text-sm md:text-base bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 disabled:scale-100 disabled:opacity-50"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending your message...
                    </div>
                  ) : (
                    "Send Project Details"
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <SuccessModal isOpen={showSuccessModal} onClose={() => setShowSuccessModal(false)} />
    </>
  )
}
